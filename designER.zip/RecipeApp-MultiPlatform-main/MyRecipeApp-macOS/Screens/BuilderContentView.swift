//
//  BuilderContentView.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/22.
//

import SwiftUI

struct BuilderContentView: View {
    var body: some View {
        NavigationView {
            BuildListView(builds: Build.all())
                .listStyle(PlainListStyle())
//                .frame(minWidth: 300)
        }
    }
}

struct BuilderContentView_Previews: PreviewProvider {
    static var previews: some View {
        BuilderContentView()
    }
}

