//
//  ContentView.swift
//  MyRecipeApp-iOS
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            RecipeListView(recipes: Recipe.all())
                .listStyle(PlainListStyle())
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
