//
//  MyRecipeApp_iOSApp.swift
//  MyRecipeApp-iOS
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import SwiftUI

@main
struct MyRecipeApp_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            TabView{
                ContentView()
                    .tabItem {
                        Text("Classes")
                        Image(systemName: "list.bullet")
                    }.tag(1)
                BuilderContentView()
                    .tabItem {
                        Text("Builds")
                        Image(systemName: "hammer.fill")
                    }.tag(2)
            }
        }
    }
}
