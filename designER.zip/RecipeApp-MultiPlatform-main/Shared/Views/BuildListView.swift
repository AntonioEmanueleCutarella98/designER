//
//  BuildListView.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import SwiftUI

struct BuildListView: View {
        
        let builds: [Build]
        
        var body: some View {
            List(builds) { build in
                NavigationLink(
                    destination: BuildView(build: build),
                    label: {
                        HStack {
                            Image(build.photo)
                                .resizable()
                                .frame(width: 100, height: 100)
                                .clipShape(RoundedRectangle(cornerRadius: 10.0, style: .continuous))
                            VStack{
                                Text(build.name).font(.headline).bold()
    //                        Text(recipe.subname).font(.subheadline)
                                
                                
                            }
                        }.padding(6)
                    })
            }.navigationTitle("Builds")
        }
    }

struct BuildListView_Previews: PreviewProvider {
    static var previews: some View {
        BuildListView(builds: Build.all())
    }
}
