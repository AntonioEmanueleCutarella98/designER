//
//  RecipeListView.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import SwiftUI

struct RecipeListView: View {
    
    let recipes: [Recipe]
    
    var body: some View {
        List(recipes) { recipe in
            NavigationLink(
                destination: RecipeDetailView(recipe: recipe),
                label: {
                    HStack {
                        Image(recipe.photo)
                            .resizable()
                            .frame(width: 100, height: 100)
                            .clipShape(RoundedRectangle(cornerRadius: 10.0, style: .continuous))
                        VStack{
                            Text(recipe.name).font(.headline).bold()
//                        Text(recipe.subname).font(.subheadline)
                            
                            
                        }
                    }.padding(6)
                })
        }.navigationTitle("Classes")
    }
}

struct RecipeListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            RecipeListView(recipes: Recipe.all())
        }
    }
}
