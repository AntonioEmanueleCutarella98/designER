//
//  BuildView.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/22.
//

import SwiftUI

struct BuildView: View {
    
    let build: Build
    
    var body: some View {
        ScrollView{
        VStack(alignment: .leading) {
                Spacer()
                Image(build.photo)
                    .resizable()
                    .frame(width: 350, height: 450)
                    .clipShape(RoundedRectangle(cornerRadius: 10.0, style: .continuous))
                    .aspectRatio(contentMode: .fit)
                    .padding()
                Spacer()
                Text(build.description)
                .padding()
            
        }.navigationTitle(build.name)
        }
    }
    }

struct BuildView_Previews: PreviewProvider {
    static var previews: some View {
        BuildView(build: Build.all()[0])
    }
}
