//
//  RecipeDetailView.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import SwiftUI

struct RecipeDetailView: View {
    
    let recipe: Recipe
    
    var body: some View {
        ScrollView{
        VStack(alignment: .leading) {
                Spacer()
                Text(recipe.subname)
                    .padding()
                Spacer()
                Image(recipe.photo2)
                    .resizable()
                    .clipShape(RoundedRectangle(cornerRadius: 10.0, style: .continuous))
                    .aspectRatio(contentMode: .fit)
                    .padding()
                Spacer()
                Text(recipe.description)
                .padding()
            
        }.navigationTitle(recipe.name)
        }
    }
    }

struct RecipeDetailView_Previews: PreviewProvider {
    static var previews: some View {
        RecipeDetailView(recipe: Recipe.all()[0])
    }
}
