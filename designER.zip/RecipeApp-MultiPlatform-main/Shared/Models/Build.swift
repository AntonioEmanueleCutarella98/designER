//
//  Build.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import Foundation

struct Build: Identifiable {
    
    let id = UUID()
    let name: String
    let photo: String
    let description: String
    
}

extension Build {
    
    static func all() -> [Build] {
        return [Build(name: "Kratos", photo: "Kratos", description: "Base Template used:Warrior\nBrow: 14,\nEyebrow Color: R39 G28 B20,\nWhite Hairs: 40,\nRight Iris Size: 210,\nRight Iris Color: R211 G126 B66 ,\nR Eye Clouding : 0,\nR Eye Position: 138,\nSkin Features:,Pores: 255,\nSkin Luster: 140,\nDark Circles: 90,\nDark Circles Color: Black,\nEyeliner:80,\nEyeliner Color:Black,\nEyeshadow(lower + Upper): 0,\nCheeks:0,\nLipstick:110,\nLipstick Color: R98 G80 B75,\nTattoo/Mark/EyePatch:,\nTattoo/Mark:13,\nTattoo/Mark Color:R100 G41 B41,\nPosition (Vert.): 211,\nPosition(Horiz.): 83,\nAngle:179,\nExpansion: 215,\nBone Structure: 1,\nForm Emphasis:0,\nApparent Age: 225,\nFacial Aesthetic: 148,\nNose Size: 98,\nNose/Forehead Ratio : 95,\nFace Protrusion: 118,\nVert. Face Ratio: 50,\nFacial Feature Slant: 108,\nHoriz. Face Ratio: 135,\nForehead Depth: 255,\nForehead Protrusion: 245,\nNose Bridge Height: 238,\nBridge Protrusion 1: 55,\nBridge Protrusion 2: 95,\nNose Bridge Width:178,\nBrow Ridge Height: 108,\nInner Brow Ridge: 128,\nOuter Brow Ridge: 158,\nEye Position:255,\nEye Size: 128,\nEye Slant: 150,\nEye Spacing: 228,\nNose Ridge Depth: 168,\nNose Ridge Length: 68,\nNose Position:148,\nNose Tip Height:165,\nNose Protrusion:95,\nNose Height:0,\nNose Slant:255,\nNostril Slant:25,\nNostril Size:78,\nNostril Width:170,\nCheekbone Height: 158,\nCheekbone Depth:158,\nCheekbone Width: 188,\nCheekbone Protrusion: 148,\nCheeks: 58,\nLip Shape:40,\nMouth Expression: 0,\nLip Fullness: 98,\nLip Size: 168,\nLip Protrusion: 198,\nLip Thickness: 118,\nMouth Protrusion:128,\nMouth Slant: 168,\nOcclusion: 128,\nMouth Position: 118,\nMouth Width: 195,\nMouth-Chin Distance: 58,\nChin Tip Position: 155,\nChin Lenght: 218,\nChin Protrusion: 68,\nChin Depth: 168,\nChin Size: 138,\nChin Height:78,\nChin Width: 138,\nJaw Protrusion: 158,\nJaw Width:118,\nLower Jaw:38,\nJaw Contour: 198,\nBody Sliders (from top to bottom): 78 206 158 208 178 ,\nSkin Color: R143 G126 B119 ,\nBeard Color: R78 G69 B61"),
            Build(name: "Herbert", photo: "Herbert", description: "Head 194,\nChest 66,\nAbdomen 9,\nArms 0,\nLegs 0,\nBody hair 125,\nMusculature standard,\nBone structure 2,\nForm emphasis 255,\nApparent age 255,\nFacial aesthetic 185,\nFacial balance ,\nNose size 253,\nNose forehead ratio 185,\nFace protrusion 192,\nVert face ratio 205,\nFacial feature slant 67,\nHoriz face ratio 246,\nForehead depth 0,\nForhead protrusion 10,\nNose bridge height 210,\nBridge protrusion 1 69 2 - 55,\nNose bridge width 204,\nBrow ridge height 75,\nInner and outer brow ridge 255,\nEyes Position 187 ,\nEye Size 245,\nEye Slant 213,\nEyeSpacing 20,\nNose Ridge depth 247,\nNose Length 226 ,\nNose Position 180,\nNose Tip height 255,\nNose Protrusion 255,\nNose height 180,\nNose Slant 255,\nNostrils Slant 24,\nNostrils Size 255,\nNostrils Width 245,\nCheeks Height 209,\nDepth 220,\nWidth 16,\nProtrusion 41,\nCheeks 122,\nLips Shape 14,\nExpression 236,\nFullness 65,\nSize 220,\nProtrusion 25,\nThickness 124,\nMouth Protrusion 22,\nSlant 115,\nOcclusion 252,\nPosition 218,\nWidth 239,\nMouth chin distance 255,\nChin Tip position 237,\nLength 255,\nProtrusion 255,\nDepth 249,\nSize 248,\nHeight,\n20,\nWidth 195,\nJaw Protrusion 91,\nWidth 114,\nLower jaw 122,\nContour 60,\nHair 1,\nLuster 0,\nRoots 0,\nWhite hairs 215,\nEyebrows 11,\nBeard 1,\nStubble 215,\nEyelashes 1,\nIris size 10,\nEye alteration off,\nEye position 140,\nSkin Pores 255,\nLuster 120,\nDark circles 255."),
                Build(name: "Geralt", photo: "Geralt", description: "Coming Soon!"),
        ]
    }
    
}
