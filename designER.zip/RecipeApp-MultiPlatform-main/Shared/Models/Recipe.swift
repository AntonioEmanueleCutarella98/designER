//
//  Recipe.swift
//  MyRecipeApp
//
//  Created by Antonio Emanuele Cutarella on 30/03/2022.
//

import Foundation


struct Recipe: Identifiable {
    let id = UUID()
    let name: String
    let photo: String
    let photo2: String
    let description: String
    let subname: String
}

extension Recipe {
    
    static func all() -> [Recipe] {
        return [Recipe(name: "Vagabond", photo: "Vagabond",photo2:"Vagabond_Stats", description: "This class starts with the following equipment:\nWeapons:Longsword,Halberd,Heater Shield.\nArmor: Vagabond Knight Helm,Vagabond Knight Armor,Vagabond Knight Gauntlets and Vagabond Knight Greaves.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A knight exiled from their homeland to wander. A solid, armor-clad origin."),
                Recipe(name: "Warrior", photo: "Warrior",photo2:"Warrior_Stats", description: "This class starts with the following equipment:\nWeapons:2x Scimitar,Riveted Wooden Shield.\nArmor:Blue Cloth Cowl,Blue Cloth Vest,Warrior Gauntlets and Warrior Greaves.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A twinblade wielding warrior from a nomadic tribe. An origin of exceptional technique."),
                Recipe(name: "Hero", photo: "Hero", photo2:"Hero_stats", description: "This class starts with the following equipment: \nWeapons: Battle Axe and a Large Leather Shield.\nArmor: Champion Headband , Champion Pauldron , Champion Bracers and Champion Gaiters.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A stalwart Hero, at home with a battleaxe, descended from a badlands chieftain."),
                Recipe(name: "Bandit", photo: "Bandit",photo2:"Bandit_Stats", description: "This class starts with the following equipment: \nWeapons: Great Knife,Shortbow,Bone Arrow (Fletched) and Buckler.\nArmor: Bandit Mask,Bandit Garb,Bandit Manchettes and Bandit Boots.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A dangerous bandit who strikes for weak points. Excels at ranged combat with bows."),
                Recipe(name: "Astrologer", photo: "Astrologer",photo2:"Astrologer_Stats", description: "This class starts with the following equipment: \nWeapons: Astrologer's Staff,Short Sword and Scripture Wooden Shield.\nArmor: Astrologer Hood,Astrologer Robe,Astrologer Gloves and Astrologer Trousers.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.",subname: "A scholar who reads fate in the stars. Heir to the school of glintstone sorcery."),
                Recipe(name: "Prophet", photo: "Prophet",photo2:"Prophet_Stats", description: "This class starts with the following equipment: \nWeapons: Heal and Catch Flame incantations,Short Spear,Finger Seal(to cast incantations),Rickety Shield\nArmor: Prophet Blindfold,Prophet Robe and Prophet Trousers.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A seer ostracized for inauspicious prophecies. Well versed in healing incantations."),
                Recipe(name: "Samurai", photo: "Samurai",photo2:"Samurai_Stats", description: "This class starts with the following equipment: \nWeapons:Uchigatana,Longbow,Arrow,Fire Arrow,Red Thorn Roundshield.\nArmor:Land of Reeds Helm,Land of Reeds Gauntlets and Land of Reeds Greaves.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A capable fighter from the distant land of reeds. Handy with Katana and Longbows."),
                Recipe(name: "Prisoner", photo: "Prisoner",photo2:"Prisoner_Stats", description: "This class starts with the following equipment: \nWeapons:Magic Glintblade,Estoc,Glintstone Staff,Rift Shield.\nArmor:Prisoner Iron Mask,Prisoner Clothing and Prisoner Trousers.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A prisoner bound in an iron mask. Studied in glintstone sorcery, having lived among the elite prior to sentencing."),
                Recipe(name: "Confessor", photo: "Confessor",photo2:"Confessor_Stats", description: "This class starts with the following equipment: \nWeapons: Urgent Heal and Assassin's Approach incantations,Broadsword,Finger Seal(to cast incantations),Blue Crest Heater Shield\nArmor: Confessor Hood,Confessor Armor,Confessor Gloves and Confessor Boots.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A church spy adept at covert operations. Equally adept with a sword as they are with incantations."),
                Recipe(name: "Wretch", photo: "Wretch",photo2:"Wretch_Stats", description: "This class starts with the following equipment: \nWeapons:Club.\nYou will also have 2 starting items , one is the Memory of Grace and the other is one of your choosing.", subname: "A poor purposeless sod naked as they day they were born. A nice club is all they have."),
        ]
    }
    
}
